package com.hemram.foodDeliv_driver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodDelivDriverApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodDelivDriverApplication.class, args);
	}

}
